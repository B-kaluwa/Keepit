import '/flutter_flow/flutter_flow_util.dart';
import 'imageview_widget.dart' show ImageviewWidget;
import 'package:flutter/material.dart';

class ImageviewModel extends FlutterFlowModel<ImageviewWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
