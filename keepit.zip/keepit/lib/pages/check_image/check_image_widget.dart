import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'check_image_model.dart';
export 'check_image_model.dart';

class CheckImageWidget extends StatefulWidget {
  const CheckImageWidget({
    super.key,
    required this.imagedoc,
  });

  final PhotosRecord? imagedoc;

  @override
  State<CheckImageWidget> createState() => _CheckImageWidgetState();
}

class _CheckImageWidgetState extends State<CheckImageWidget> {
  late CheckImageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CheckImageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      FlutterFlowIconButton(
                        borderColor: FlutterFlowTheme.of(context).primaryText,
                        borderRadius: 30.0,
                        borderWidth: 3.0,
                        buttonSize: 50.0,
                        icon: Icon(
                          Icons.arrow_back_rounded,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 34.0,
                        ),
                        onPressed: () async {
                          context.safePop();
                        },
                      ),
                      FlutterFlowIconButton(
                        borderColor: FlutterFlowTheme.of(context).primaryText,
                        borderRadius: 30.0,
                        borderWidth: 3.0,
                        buttonSize: 50.0,
                        icon: const FaIcon(
                          FontAwesomeIcons.trashAlt,
                          color: Color(0xFF790E1D),
                          size: 34.0,
                        ),
                        onPressed: () async {
                          await widget.imagedoc!.reference.delete();
                          context.safePop();
                        },
                      ),
                    ],
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.network(
                    widget.imagedoc!.image,
                    width: 318.0,
                    height: 618.0,
                    fit: BoxFit.cover,
                  ),
                ),
                Icon(
                  Icons.download_sharp,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 54.0,
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
