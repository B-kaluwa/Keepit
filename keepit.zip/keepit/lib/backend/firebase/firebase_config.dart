import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyAA-KslK62YxejYsw5vngshc4FL_Q_w_3U",
            authDomain: "vet-careapp1-kw9lsd.firebaseapp.com",
            projectId: "vet-careapp1-kw9lsd",
            storageBucket: "vet-careapp1-kw9lsd.appspot.com",
            messagingSenderId: "791259653986",
            appId: "1:791259653986:web:a2512859c6962544506e3b"));
  } else {
    await Firebase.initializeApp();
  }
}
