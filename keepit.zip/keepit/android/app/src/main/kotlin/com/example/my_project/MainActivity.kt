package com.mycompany.vetcareapp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
